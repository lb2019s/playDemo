# react-server-dom-webpack

Experimental React Flight bindings for DOM using Webpack.

**Use it at your own risk.**
