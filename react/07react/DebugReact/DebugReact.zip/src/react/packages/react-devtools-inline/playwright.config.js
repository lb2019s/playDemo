const config = {
  use: {
    headless: false,
    browserName: 'chromium',
    launchOptions: {
      slowMo: 100,
    },
  },
};

module.exports = config;
