# use-sync-external-store

Backwards compatible shim for React's `useSyncExternalStore`. Works with any React that supports hooks.

Until `useSyncExternalStore` is documented, refer to https://github.com/reactwg/react-18/discussions/86
